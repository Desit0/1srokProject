public class RationalTest {
}
