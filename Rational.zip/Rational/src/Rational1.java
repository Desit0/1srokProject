import java.util.Scanner;

public class Rational1 {
    private int n;
    private int d;
    private int r;
    private int br=0;
    Scanner input = new Scanner(System.in);

    public int getn() {
        return n;
    }

    public void setn(int n) {
        if (n > 0) {
            this.n = n;
        }
    }

    public int getd() {
        return d;
    }

    public void setd(int d) {
        if (d > 0) {
            this.d = d;
        }
    }

    public int getr() {
        return r;
    }

    public void setr(int r) {
        if (r > 0) {
            this.r = r;
        }
    }
    public int getbr() {
        return br;
    }

    public void setbr(int br) {
        if (br > 0) {
            this.br = br;
        }
    }

    public Rational1(int n, int d, int r,int br) {
        setn(n);
        setd(d);
        setr(r);
        setbr(br);
    }

    public int Funk(int n, int d,int br) {
        if (n >= d) {
            for (int i = 1; i < n; i++) {
                if (n % i == 0 || d % i == 0) {
                    if (br < i) {
                        br = i;
                    }

                }
            }
            System.out.println((n / br) + "/" + (d / br));
        } else
            for (int i = 1; i < d; i++) {
                if (n % i == 0 || d % i == 0) {
                    if (br < i) {
                        br = i;
                    }

                }
            }

    }
        @Override
        public String toString() {


        return String.format("%d/%d",((n / br) + "/" + (d / br) );
    }
}
}